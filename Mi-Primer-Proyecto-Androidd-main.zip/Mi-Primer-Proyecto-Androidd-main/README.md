# Mi-Primer-Proyecto-Androidd

Crea un proyecto en Android que:

Soporte cuatro idiomas.
Utilice la imagen adjunta como fondo generando su archivo nine-patch para que sea redimensionable.
Brinde soporte a múltiples pantallas.
